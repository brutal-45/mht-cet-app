// Types and accessors for the provisional merit list (PCM, 2026-27).
//
// Data is stored as a compact array-of-arrays JSON to keep bundle size under
// Vercel's 50 MB serverless function limit (~40 MB for 227,048 students).
//
// Field order is defined in the JSON itself (the `fields` array), so we read
// it dynamically and expose typed accessors.

import studentDataRaw from "@/data/students.json";

export interface Student {
  merit_no: number;
  app_id: string;
  name: string;
  category: string;
  gender: string;
  yes_count: number;
  minority: string;
  merit_percentile: string;
  math_percentile: string;
  physics_percentile: string;
  chemistry_percentile: string;
  hsc_pcm: string;
  hsc_math: string;
  hsc_physics: string;
  hsc_total: string;
  ssc_total: string;
  ssc_math: string;
  ssc_science: string;
  ssc_english: string;
}

interface RawData {
  fields: string[];
  count: number;
  students: unknown[][];
}

const rawData = studentDataRaw as RawData;

// Build field index lookup once
const fieldIndex: Record<string, number> = {};
rawData.fields.forEach((f, i) => {
  fieldIndex[f] = i;
});

// Convert a raw row array into a typed Student object
function rowToStudent(row: unknown[]): Student {
  return {
    merit_no: row[fieldIndex.merit_no] as number,
    app_id: row[fieldIndex.app_id] as string,
    name: row[fieldIndex.name] as string,
    category: row[fieldIndex.category] as string,
    gender: row[fieldIndex.gender] as string,
    yes_count: row[fieldIndex.yes_count] as number,
    minority: row[fieldIndex.minority] as string,
    merit_percentile: row[fieldIndex.merit_percentile] as string,
    math_percentile: row[fieldIndex.math_percentile] as string,
    physics_percentile: row[fieldIndex.physics_percentile] as string,
    chemistry_percentile: row[fieldIndex.chemistry_percentile] as string,
    hsc_pcm: row[fieldIndex.hsc_pcm] as string,
    hsc_math: row[fieldIndex.hsc_math] as string,
    hsc_physics: row[fieldIndex.hsc_physics] as string,
    hsc_total: row[fieldIndex.hsc_total] as string,
    ssc_total: row[fieldIndex.ssc_total] as string,
    ssc_math: row[fieldIndex.ssc_math] as string,
    ssc_science: row[fieldIndex.ssc_science] as string,
    ssc_english: row[fieldIndex.ssc_english] as string,
  };
}

// Lazy-loaded cache
let studentsCache: Student[] | null = null;

export function getAllStudents(): Student[] {
  if (studentsCache) return studentsCache;
  studentsCache = rawData.students.map(rowToStudent);
  return studentsCache;
}

export function getStudentCount(): number {
  return rawData.count;
}

/**
 * Look up a student by merit number (rank). Returns null if not found.
 */
export function getStudentByRank(rank: number): Student | null {
  // Binary search — students are sorted by merit_no
  const all = getAllStudents();
  let lo = 0;
  let hi = all.length - 1;
  while (lo <= hi) {
    const mid = (lo + hi) >> 1;
    const m = all[mid].merit_no;
    if (m === rank) return all[mid];
    if (m < rank) lo = mid + 1;
    else hi = mid - 1;
  }
  return null;
}

/**
 * Search students by MHT-CET percentile.
 *
 * Behavior:
 *   - If `query` exactly matches a percentile (e.g. "99.8987775"), returns
 *     all students with that exact percentile (usually 1-5 students due to
 *     ties), sorted by merit_no.
 *   - If `query` is a prefix (e.g. "99.89"), returns all students whose
 *     percentile starts with that prefix, sorted by merit_no (closest to 100
 *     first since merit_no is ascending).
 *
 * Returns at most `limit` results (default 50).
 */
export function searchByPercentile(query: string, limit = 50): Student[] {
  const q = query.trim();
  if (!q) return [];

  // Validate: percentile should be a number 0-100, possibly with decimals
  if (!/^\d+(\.\d+?)?$/.test(q)) return [];
  if (parseFloat(q) > 100) return [];

  const all = getAllStudents();
  const matches: Student[] = [];

  // Linear scan — we can't binary search on a string prefix
  // (but the data is sorted by merit_no, which correlates with percentile DESC)
  for (let i = 0; i < all.length; i++) {
    if (all[i].merit_percentile.startsWith(q)) {
      matches.push(all[i]);
      if (matches.length >= limit) break;
    }
  }

  // Sort by merit_no ascending (best rank first)
  matches.sort((a, b) => a.merit_no - b.merit_no);
  return matches;
}

/**
 * Search students by rank (merit number). Returns exact match plus nearby
 * students (so the user can scroll through neighbors). Default returns the
 * matched student + 4 above + 5 below (10 total).
 */
export function searchByRankWithNeighbors(rank: number, around = 5): Student[] {
  const all = getAllStudents();
  const idx = all.findIndex((s) => s.merit_no === rank);
  if (idx < 0) return [];

  const start = Math.max(0, idx - around);
  const end = Math.min(all.length, idx + around + 1);
  return all.slice(start, end);
}
