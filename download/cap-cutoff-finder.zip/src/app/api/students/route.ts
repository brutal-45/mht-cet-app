import { NextResponse } from "next/server";
import {
  getAllStudents,
  getStudentCount,
  searchByPercentile,
} from "@/lib/students";

export const dynamic = "force-dynamic";

// Cache the slim student index in memory across warm invocations
interface SlimStudent {
  merit_no: number;
  app_id: string;
  name: string;
  category: string;
  gender: string;
  merit_percentile: string;
}

let slimCache: SlimStudent[] | null = null;

function getSlimIndex(): SlimStudent[] {
  if (slimCache) return slimCache;
  slimCache = getAllStudents().map((s) => ({
    merit_no: s.merit_no,
    app_id: s.app_id,
    name: s.name,
    category: s.category,
    gender: s.gender,
    merit_percentile: s.merit_percentile,
  }));
  return slimCache;
}

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const q = (searchParams.get("q") ?? "").trim();
  const mode = (searchParams.get("mode") ?? "auto").trim();
  const limit = Math.min(
    100,
    Math.max(1, parseInt(searchParams.get("limit") ?? "50", 10) || 50)
  );

  // Empty query → return total count + a few sample students (top 10)
  if (!q) {
    const count = getStudentCount();
    const sample = getSlimIndex().slice(0, 10);
    return NextResponse.json({
      count,
      results: sample,
      total: count,
    });
  }

  // Decide search mode
  // "auto" → if query is purely digits, search by rank; otherwise by percentile
  // "rank" → search by rank (merit_no)
  // "percentile" → search by percentile
  let effectiveMode = mode;
  if (mode === "auto") {
    effectiveMode = /^\d{1,6}$/.test(q) && !q.includes(".")
      ? "rank"
      : "percentile";
  }

  if (effectiveMode === "rank") {
    const rank = parseInt(q, 10);
    if (!Number.isFinite(rank) || rank < 1) {
      return NextResponse.json({
        count: 0,
        results: [],
        mode: "rank",
      });
    }
    // Find the student with this rank + nearby neighbors
    const all = getAllStudents();
    const idx = all.findIndex((s) => s.merit_no === rank);
    if (idx < 0) {
      // Find closest rank
      const closest = all.reduce((best, s, i) => {
        const diff = Math.abs(s.merit_no - rank);
        return diff < best.diff ? { idx: i, diff } : best;
      }, { idx: -1, diff: Infinity });
      if (closest.idx < 0) {
        return NextResponse.json({ count: 0, results: [], mode: "rank" });
      }
      const start = Math.max(0, closest.idx - 5);
      const end = Math.min(all.length, closest.idx + 6);
      const results = all.slice(start, end).map((s) => ({
        merit_no: s.merit_no,
        app_id: s.app_id,
        name: s.name,
        category: s.category,
        gender: s.gender,
        merit_percentile: s.merit_percentile,
      }));
      return NextResponse.json({
        count: results.length,
        results,
        mode: "rank",
        exact_match: false,
      });
    }
    const start = Math.max(0, idx - 5);
    const end = Math.min(all.length, idx + 6);
    const results = all.slice(start, end).map((s) => ({
      merit_no: s.merit_no,
      app_id: s.app_id,
      name: s.name,
      category: s.category,
      gender: s.gender,
      merit_percentile: s.merit_percentile,
    }));
    return NextResponse.json({
      count: results.length,
      results,
      mode: "rank",
      exact_match: true,
    });
  }

  // Percentile search
  if (!/^\d+(\.\d+?)?$/.test(q) || parseFloat(q) > 100) {
    return NextResponse.json({
      count: 0,
      results: [],
      mode: "percentile",
      error: "Invalid percentile. Please enter a number between 0 and 100.",
    });
  }

  const matches = searchByPercentile(q, limit);
  const results: SlimStudent[] = matches.map((s) => ({
    merit_no: s.merit_no,
    app_id: s.app_id,
    name: s.name,
    category: s.category,
    gender: s.gender,
    merit_percentile: s.merit_percentile,
  }));

  return NextResponse.json({
    count: results.length,
    results,
    mode: "percentile",
    exact_match: matches.length > 0 && matches[0]?.merit_percentile === q,
    limited: matches.length === limit,
  });
}
